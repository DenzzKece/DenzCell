package com.denzzcell.kasir;
import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private WebView web;
    private BluetoothSocket socket;
    private BluetoothAdapter adapter;
    private static final int BT_PERMISSION_REQUEST = 42;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        adapter = BluetoothAdapter.getDefaultAdapter();
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new PrinterBridge(), "AndroidPrinter");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissionIfNeeded();
    }
    private boolean hasConnectPermission() {
        return Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }
    private void requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 && !hasConnectPermission())
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, BT_PERMISSION_REQUEST);
    }
    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == BT_PERMISSION_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED)
            web.evaluateJavascript("if(typeof loadBtDevices==='function'){loadBtDevices();}", null);
    }
    private class PrinterBridge {
        @JavascriptInterface public String getPairedDevices() {
            try {
                if (!hasConnectPermission() || adapter == null || !adapter.isEnabled()) return "[]";
                JSONArray array = new JSONArray();
                Set<BluetoothDevice> devices = adapter.getBondedDevices();
                for (BluetoothDevice device : devices) {
                    JSONObject item = new JSONObject();
                    item.put("name", device.getName() == null ? "Printer Bluetooth" : device.getName());
                    item.put("address", device.getAddress());
                    array.put(item);
                }
                return array.toString();
            } catch (Exception e) { return "[]"; }
        }
        @JavascriptInterface public boolean isConnected() { return socket != null && socket.isConnected(); }
        @JavascriptInterface public String connect(String address) {
            try {
                if (!hasConnectPermission()) return "Izin Bluetooth belum diberikan";
                if (adapter == null) return "Perangkat tidak mendukung Bluetooth";
                if (!adapter.isEnabled()) return "Aktifkan Bluetooth Android terlebih dahulu";
                if (socket != null) { try { socket.close(); } catch (Exception ignored) {} socket = null; }
                BluetoothDevice device = adapter.getRemoteDevice(address);
                BluetoothSocket newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                newSocket.connect();
                socket = newSocket;
                return "OK";
            } catch (Exception e) { return e.getMessage() == null ? "Koneksi gagal" : e.getMessage(); }
        }
        @JavascriptInterface public String print(String text) {
            try {
                if (socket == null || !socket.isConnected()) return "Printer belum terhubung";
                OutputStream out = socket.getOutputStream();
                out.write(new byte[]{0x1B,0x40});
                out.write(new byte[]{0x1B,0x61,0x01});
                out.write(text.getBytes("UTF-8"));
                out.write(new byte[]{0x0A,0x0A,0x0A});
                out.write(new byte[]{0x1D,0x56,0x00});
                out.flush();
                return "OK";
            } catch (Exception e) { return e.getMessage() == null ? "Gagal mengirim struk" : e.getMessage(); }
        }
    }
    @Override public void onBackPressed() { if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    @Override protected void onDestroy() { try { if (socket != null) socket.close(); } catch (Exception ignored) {} super.onDestroy(); }
}
