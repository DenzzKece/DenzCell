# DenzzCell Kasir Android

Aplikasi Android offline dengan logo DenzzCell dan dukungan printer thermal Bluetooth 58mm melalui Bluetooth Classic SPP / ESC-POS.

## Build APK lewat GitHub
1. Buat repository baru di GitHub.
2. Upload seluruh isi proyek ini ke root repository.
3. Buka tab **Actions**.
4. Pilih workflow **Build DenzzCell APK**, lalu tekan **Run workflow**.
5. Setelah selesai, unduh artifact `DenzzCell-debug-apk` dan ekstrak `app-debug.apk`.

## Menghubungkan printer 58mm
1. Nyalakan printer dan Bluetooth Android.
2. Pasangkan printer melalui Pengaturan Android > Bluetooth.
3. Buka DenzzCell dan izinkan akses perangkat Bluetooth saat diminta.
4. Buka Riwayat Transaksi, tekan **Muat ulang perangkat**.
5. Pilih printer, tekan **Hubungkan**.
6. Tekan **Cetak** pada transaksi. Jika sudah terhubung, struk dikirim langsung melalui Bluetooth.

Printer harus mendukung Bluetooth Classic SPP dan ESC/POS. Printer BLE-only atau protokol khusus mungkin tidak kompatibel.

Login awal: `admin` / `123456`. Ubah password setelah masuk.
Data tersimpan lokal pada perangkat. Ekspor cadangan secara berkala.
APK workflow adalah debug APK untuk uji coba, belum release APK bertanda tangan.
Pembuat: **DENIS FIRMANSAH**.
